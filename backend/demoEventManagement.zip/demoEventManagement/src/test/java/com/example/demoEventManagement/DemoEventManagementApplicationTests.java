package com.example.demoEventManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEventManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
